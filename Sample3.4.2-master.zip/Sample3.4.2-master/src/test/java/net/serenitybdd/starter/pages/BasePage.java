package net.serenitybdd.starter.pages;

import org.openqa.selenium.WebDriver;

import net.serenitybdd.core.pages.PageObject;

public abstract class BasePage extends PageObject{
	
	
	public BasePage(WebDriver driver) {
		super(driver);
	}
	
	
	
}